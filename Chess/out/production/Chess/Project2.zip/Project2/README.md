Group Members: Cole Mische, misch123

How to compile and run:
Compile the following files:
Bishop.java
Board.java
Fen.java
Game.java
King.java
Knight.java
Pawn.java
Piece.java
Queen.java
Rook.java
How to run program:
Compile all java files and run Game.java

        Format for moving pieces [start row] [start col] [end row] [end col]

Additional Features:
None

Known Bugs/Defects:
Sometimes issues with move validity crashing the game, unfortunately out of time to fix cause I'm bad at time management

Any outside sources:
- https://www.w3schools.com/java/java_switch.asp
- https://www.w3schools.com/java/java_user_input.asp

I certify that the information contained in this README file is complete and accurate. I have both read and followed the course policies in the ‘Academic Integrity - Course Policy’ section of the course syllabus
- Cole Mische

